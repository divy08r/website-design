import React from 'react'
import Home from './screens/Home'

export default function App() {
  return (
    <div>
      <Home/>
    </div>
  )
}
